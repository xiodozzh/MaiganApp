//package com.mgtech.blelib.net;
//
//import com.google.gson.annotations.SerializedName;
//import com.mgtech.blelib.constant.NetConstant;
//
///**
// * Created by zhaixiang on 2017/12/15.
// * 保存步数
// */
//
//public class SaveStepItemEntity {
//    @SerializedName(NetConstant.JSON_REQUEST_DATE)
//    private String date;
//    @SerializedName(NetConstant.JSON_DURATION)
//    private float duration;
//    @SerializedName(NetConstant.JSON_DISTANCE)
//    private float distance;
//    @SerializedName(NetConstant.JSON_HEAT)
//    private float heat;
//    @SerializedName(NetConstant.JSON_STEP_NUM)
//    private float stepNum;
//
//
//    public String getDate() {
//        return date;
//    }
//
//    public void setDate(String date) {
//        this.date = date;
//    }
//
//    public float getDuration() {
//        return duration;
//    }
//
//    public void setDuration(float duration) {
//        this.duration = duration;
//    }
//
//    public float getDistance() {
//        return distance;
//    }
//
//    public void setDistance(float distance) {
//        this.distance = distance;
//    }
//
//    public float getHeat() {
//        return heat;
//    }
//
//    public void setHeat(float heat) {
//        this.heat = heat;
//    }
//
//    public float getStepNum() {
//        return stepNum;
//    }
//
//    public void setStepNum(float stepNum) {
//        this.stepNum = stepNum;
//    }
//
//
//    @Override
//    public String toString() {
//        return "StepDetailItemEntity{" +
//                "date='" + date + '\'' +
//                ", duration=" + duration +
//                ", distance=" + distance +
//                ", heat=" + heat +
//                ", stepNum=" + stepNum +
//                '}';
//    }
//}
