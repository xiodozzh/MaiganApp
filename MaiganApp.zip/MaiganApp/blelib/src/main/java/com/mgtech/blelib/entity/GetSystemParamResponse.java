package com.mgtech.blelib.entity;

import com.mgtech.blelib.biz.BluetoothConfig;
import com.mgtech.blelib.constant.BleConstant;

import java.util.ArrayList;
import java.util.List;

public class GetSystemParamResponse {
    private SystemParamData systemParamData;

    public void set(byte[] data) {
        if (data.length < 4) {
            return;
        }
        if (data[2] == BluetoothConfig.ERROR_NONE) {
            systemParamData = new SystemParamData();
            DisplayPage pageDisplayData = new DisplayPage();
            int i = 4;
            while (i < data.length) {
                int type = data[i];
                switch (type) {
                    case SystemParamData.PARAM_REMINDERS:
                        int reminderNum = data[i + 1];
                        List<AlertReminder> items = new ArrayList<>();
                        for (int j = 0; j < reminderNum; j++) {
                            AlertReminder item = new AlertReminder();
                            item.setReminderEnable(data[i + 2 + 6 * j] == 0x1);
                            item.setReminderWeek(data[i + 3 + 6 * j]);
                            item.setReminderStartHour(data[i + 4 + 6 * j]);
                            item.setReminderStartMinute(data[i + 5 + 6 * j]);
                            item.setReminderSpanTime((data[i + 6 + 6 * j] & 0xFF) + ((data[i + 7 + 6 * j] & 0xFF) << 8));
                            items.add(item);
                        }
                        systemParamData.setReminders(items);
                        i += reminderNum * 6 + 2;
                        break;
                    case SystemParamData.PARAM_LANGUAGE:
                        systemParamData.setLang(data[i + 1]);
                        i += 2;
                        break;
                    case SystemParamData.PARAM_HEIGHT:
                        systemParamData.setHeight(data[i + 1]);
                        i += 2;
                        break;
                    case SystemParamData.PARAM_WEIGHT:
                        systemParamData.setWeight(data[i + 1]);
                        i += 2;
                        break;
                    case SystemParamData.PARAM_DATE:
                        systemParamData.setDatePageDisplay(data[i + 1]);
                        i += 2;
                        break;
                    case SystemParamData.PARAM_POWER:
                        pageDisplayData.setPowerPageDisplay(data[i + 1]);
                        systemParamData.setPageDisplayData(pageDisplayData);
                        i += 2;
                        break;
                    case SystemParamData.PARAM_CALCULATE_RESULT_DISPLAY:
                        int resultNumber = data[i + 1];
                        for (int j = 0; j < resultNumber; j++) {
                            int t = data[i + 2 + j * 2];
                            switch (t) {
                                case BleConstant.INDEX_PS:
                                    pageDisplayData.setBpPageDisplay(data[i + 3 + j * 2]);
                                    break;
                                case BleConstant.INDEX_PD:
                                    pageDisplayData.setBpPageDisplay(data[i + 3 + j * 2]);
                                    break;
                                case BleConstant.INDEX_V0:
                                    pageDisplayData.setV0PageDisplay(data[i + 3 + j * 2]);
                                    break;
                                default:
                            }
                        }
                        systemParamData.setPageDisplayData(pageDisplayData);
                        i += 2 + resultNumber * 2;
                        break;
                    case SystemParamData.PARAM_SPORT:
                        int sportNum = data[i + 1];
                        for (int j = 0; j < sportNum; j++) {
                            int t = data[i + 2 + j * 2];
                            switch (t) {
                                case BleConstant.PAGE_STEP:
                                    pageDisplayData.setStepPageDisplay(data[i + 3 + j * 2]);
                                    break;
                                case BleConstant.PAGE_DISTANCE:
                                    pageDisplayData.setDistancePageDisplay(data[i + 3 + j * 2]);
                                    break;
                                case BleConstant.PAGE_HEAT:
                                    pageDisplayData.setHeatPageDisplay(data[i + 3 + j * 2]);
                                    break;
                                default:
                            }
                        }
                        systemParamData.setPageDisplayData(pageDisplayData);
                        i += 2 + sportNum * 2;
                        break;
                    default:
                }
            }
        }
    }


    public SystemParamData getSystemParamData() {
        return systemParamData;
    }

}
