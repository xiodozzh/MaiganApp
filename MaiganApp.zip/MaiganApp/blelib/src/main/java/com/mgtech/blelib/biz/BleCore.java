package com.mgtech.blelib.biz;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.mgtech.blelib.constant.BleConstant;
import com.mgtech.blelib.core.BleClient2;
import com.mgtech.blelib.core.BleClientCallback2;
import com.mgtech.blelib.core.BleCoreConstant;
import com.mgtech.blelib.core.ParsedAd;
import com.mgtech.blelib.core.ParsedBleBroadcast;
import com.mgtech.blelib.entity.AlertReminder;
import com.mgtech.blelib.entity.BroadcastData;
import com.mgtech.blelib.entity.CheckDeviceData;
import com.mgtech.blelib.entity.CurrentStepData;
import com.mgtech.blelib.entity.DisplayPage;
import com.mgtech.blelib.entity.FirmStateData;
import com.mgtech.blelib.entity.FirmwareInfoData;
import com.mgtech.blelib.entity.GetSystemParamResponse;
import com.mgtech.blelib.entity.HeightWeightData;
import com.mgtech.blelib.entity.ManualEcgError;
import com.mgtech.blelib.entity.ManualMeasureNewOrder;
import com.mgtech.blelib.entity.ManualPwError;
import com.mgtech.blelib.entity.ManualSampleData;
import com.mgtech.blelib.entity.MeasureEcgData;
import com.mgtech.blelib.entity.MeasurePwData;
import com.mgtech.blelib.entity.PairRequestResponse;
import com.mgtech.blelib.entity.StepHistory;
import com.mgtech.blelib.entity.StoredSampleData;
import com.mgtech.blelib.utils.AESUtils;
import com.mgtech.blelib.utils.UpgradeFirmwareManager;
import com.orhanobut.logger.Logger;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.zip.CRC32;

/**
 * @author zhaixiang
 */
public class BleCore {
    private static final int AUTO_SAMPLE_DOUBLE_POINT_SIZE = ManualMeasureNewOrder.COMPLETE_POINTS;
    private static final String TAG = "BleCore";
    private static final int MTU = 512;
    private BleClient2 bleClient;
    private Context context;
    private IBraceletInfoManager manager;
    private BleSender bleSender;
    private static Handler mHandler = new Handler();

    private BleOrder bleOrder;
    private BleState bleState;

    private MeasureEcgData measureEcgData;
    private MeasurePwData measurePwData;

    public BleCore(Context context, BleClient2 bleClient, IBraceletInfoManager manager, BleSender bleSender,
                   BleOrder bleOrder, BleState bleState) {
        this.bleClient = bleClient;
        this.bleClient.setCallback(clientCallback);
        this.context = context;
        this.manager = manager;
        this.bleSender = bleSender;
        this.bleOrder = bleOrder;
        this.bleState = bleState;
    }

    public void setMeasureEcgData(MeasureEcgData measureEcgData) {
        this.measureEcgData = measureEcgData;
    }

    public void setMeasurePwData(MeasurePwData measurePwData) {
        this.measurePwData = measurePwData;
    }

    private BleClientCallback2 clientCallback = new BleClientCallback2() {

        @Override
        public void onConnected() {
            Log.i(TAG, "onConnected: ");
            bleSender.connected();
            bleState.setConnected(true);
            boolean success = bleClient.requestMtu(MTU);
            if (!success) {
                Log.i(TAG, "设置mtu失败");
                bleClient.disconnect();
            }
        }

        @Override
        public void connectExistingConnection(boolean exist) {
        }

        @Override
        public void onDisConnected() {
            bleState.setSampling(false);
            bleState.setUpgrading(false);
            bleState.setReady(false);
            bleState.setWorking(false);
            bleState.setConnected(false);
            bleState.clear();
            bleSender.disconnect();
        }

        @Override
        public void onServiceDiscovered() {
            enableVerificationNotification();
        }

        @Override
        public void onWrite(boolean status, String s) {
        }

        @Override
        public void onRead(boolean status, String s, byte[] value) {
        }

        @Override
        public void onDataTransferEnabled(String uuid) {
            if (TextUtils.equals(uuid, BleCoreConstant.CHAR_VERIFICATION_RESPONSE)) {
                // 非加密使能后使能加密通知
                enableNotification();
            } else {
                // 加密使能后设置
                BroadcastData linkedBroadcastData = bleState.getLinkedBroadcastData();
                if (linkedBroadcastData != null) {
                    bleSender.startVerify();
                    bleOrder.verifyWork(linkedBroadcastData.getMacAddressBytes(), linkedBroadcastData.getPairCode());
                } else if (manager.isPaired()) {
                    bleSender.startVerify();
                    bleOrder.verifyWork(bleOrder.getMacBytes(), manager.getCodePair());
                } else {
                    Log.i(TAG, "onMtuChanged: macAddressBytes == null");
                    bleClient.disconnect();
                }
            }
        }

        @Override
        public void onDataReceived(String uuid, byte[] receivedData) {
            Log.i(TAG, "onDataReceived: " + uuid);
            if (uuid.equals(BleCoreConstant.CHAR_RESPONSE)) {
                onReceivedData(receivedData);
            } else if (uuid.equals(BleCoreConstant.CHAR_VERIFICATION_RESPONSE)) {
                onReceivedVerificationData(receivedData);
            }
        }

        @Override
        public void onRRSIChanged(int rssi) {
        }

        @Override
        public void onError() {

        }

        @Override
        public void onMtuChanged(int mtu, int status) {
            Log.i(TAG, "MTU 修改成为: " + mtu);
            bleClient.discoverServices();
        }
    };

    public void startPairScan(String[] name) {
        bleClient.startScan(name, pairScan);
    }

    public void startScan(String[] name, String mac) {
        bleClient.startScan(context, name, mac, linkScan);
    }

    public void stopScan() {
        bleClient.stopScan(pairScan);
        bleClient.stopScan(linkScan);
    }

    public void connect(String mac) {
        bleClient.connect(context, mac);
    }

    public void disconnect() {
        stopScan();
        bleClient.disconnect();
    }

    private ScanCallback pairScan = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice device = result.getDevice();
            Log.i(TAG, "onScanResult: " + device.getName() + "  " + device.getAddress());
            Log.i(TAG, "onScanResult: " + result.getScanRecord());
            int rssi = result.getRssi();
            if (result.getScanRecord() != null) {
                byte[] data = result.getScanRecord().getBytes();
                ParsedAd parsedAd = ParsedAd.parseData(data);
                if (!manager.isPaired()) {
                    ParsedBleBroadcast broadcastCandidate = parsedAd.getParsedBleBroadcast();
                    if (broadcastCandidate != null) {
                        Logger.e("broadcast: " + broadcastCandidate.toString());
                        if (isBroadcastSignatureCorrect(broadcastCandidate)
                                && broadcastCandidate.getBroadcastReason() == BluetoothConfig.BROADCAST_ALLOW_BOND) {
                            Log.e(TAG, "广播签名正确 ");
                            broadcastCandidate.setDeviceName(device.getName());
                            BroadcastData broadcastData = new BroadcastData(device.getAddress().toUpperCase(), rssi,
                                    Calendar.getInstance().getTimeInMillis(), broadcastCandidate);
                            bleSender.sendBroadcast(broadcastData);
                            bleState.setLinkedBroadcastData(broadcastData);
                        } else {
                            Log.e(TAG, "onScanResults: 签名不正确或广播方式不正确");
                        }
                    }

                }
            }
        }
    };

    private ScanCallback linkScan = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice device = result.getDevice();
            if (result.getScanRecord() != null) {
                byte[] data = result.getScanRecord().getBytes();
                int rssi = result.getRssi();
                ParsedAd parsedAd = ParsedAd.parseData(data);
                if (manager.isPaired() && manager.getAddress().equals(device.getAddress())) {
                    ParsedBleBroadcast broadcastCandidate = parsedAd.getParsedBleBroadcast();
                    broadcastCandidate.setDeviceName(device.getName());
                    if (!isPaired(broadcastCandidate.getPairCode())) {
                        // 配对码错误,链接断开
                        manager.deletePairInformation();
                        stopScan();
                        bleSender.sendPairCodeDifferent();
                        return;
                    }
                    if (isBroadcastSignatureCorrect(broadcastCandidate)) {
                        bleState.setLinkedBroadcastData(new BroadcastData(device.getAddress().toUpperCase(), rssi,
                                Calendar.getInstance().getTimeInMillis(), broadcastCandidate));
                        connectDevice(broadcastCandidate);
                    } else {
                        Log.e(TAG, "onScanResults: 签名不正确");
                    }
                }
            }


        }
    };

    /**
     * 连接广播
     *
     * @param data 广播包
     */
    public void connectDevice(BroadcastData data) {
        stopScan();
        bleClient.connect(context, data.getMacAddress());
    }

    private void connectDevice(ParsedBleBroadcast broadcastCandidate) {
        stopScan();
        bleClient.connect(context, manager.getAddress());
        if (broadcastCandidate != null) {
            manager.saveDeviceName(broadcastCandidate.getDeviceName());
            manager.saveDeviceProtocolVersion(broadcastCandidate.getProtocolVersion());
        }
    }

    /**
     * 广播包签名是否正确
     *
     * @return boolean
     */
    private boolean isBroadcastSignatureCorrect(ParsedBleBroadcast broad) {
        byte[] mac = broad.getMacAddress();
        byte[] sign = broad.getSignature();
        int pairCode = broad.getPairCode();
        if (sign.length == 2) {
            return mac.length == 6 && (byte) (mac[1] ^ mac[2]) == sign[0] &&
                    (byte) (mac[0] ^ (pairCode & 0xFF)) == sign[1];
        } else if (sign.length == 1) {
            return mac.length == 6 && (byte) (mac[0] ^ (pairCode & 0xFF)) == sign[0];
        }
        return false;
    }

    private boolean isPaired(int pairCode) {
        int storedPairCode = manager.getCodePair();
        Log.e(TAG, "broadcast: " + pairCode + "  stored " + storedPairCode);
        return manager.isPaired() && pairCode != 0 && storedPairCode == pairCode;
    }

    /**
     * 使能非加密通道
     */
    private void enableVerificationNotification() {
        Log.e(TAG, "run: enableVerificationNotification");
        bleClient.toggleNotification(BleCoreConstant.MG_PROFILE_SERVICE,
                BleCoreConstant.CHAR_VERIFICATION_RESPONSE, true);
    }

    /**
     * 使能加密通道
     */
    private void enableNotification() {
        Log.e(TAG, "run: enableNotification ");
        bleClient.toggleNotification(BleCoreConstant.MG_PROFILE_SERVICE, BleCoreConstant.CHAR_RESPONSE, true);
    }


    /**
     * 保存配对需要的信息 密钥和配对码
     */
    private void savePairInfo(byte[] encryptKey, byte[] encryptVector, String deviceUUID) {
        Log.e(TAG, "保存配对需要的信息 密钥和配对码");
        BroadcastData linkedBroadcastData = bleState.getLinkedBroadcastData();
        int pairCode = linkedBroadcastData.getPairCode();
        if (pairCode == 0XFFFFFFFF) {
            pairCode = 1;
        } else {
            pairCode++;
        }
        manager.savePairInformation(linkedBroadcastData.getDeviceName(), linkedBroadcastData.getMacAddress(),
                pairCode, encryptKey,
                encryptVector, deviceUUID, Calendar.getInstance().getTimeInMillis(), linkedBroadcastData.getProtocolVersion(),
                linkedBroadcastData.getFirmwareVersion(), linkedBroadcastData.getHardwareVersion());
        linkedBroadcastData.setPairCode(pairCode);
    }


    /**
     * 收到校验数据
     *
     * @param receivedData 数据
     */
    private void onReceivedVerificationData(byte[] receivedData) {
        byte[] data = AESUtils.decrypt(getNormalEncryptKey(), receivedData, getNormalEncryptVector());
        if (data.length < 1) {
            bleClient.disconnect();
            return;
        }
        Log.e(TAG, "onReceivedVerificationData: " + Arrays.toString(data));
        switch (data[0]) {
            case BluetoothConfig.CODE_AUTH_LINK:
                onAuthData(data);
                break;
            case BluetoothConfig.CODE_REQUEST_PAIR:
                onPairRequest(data);
                break;
            default:
        }
    }

    /**
     * 手环校验应答
     *
     * @param data byte[]
     */
    private void onAuthData(byte[] data) {
        if (data.length == 3 && data[1] == bleState.getGenerator().get() && data[2] == BluetoothConfig.ERROR_NONE) {
            // ready的状态
            bleState.setReady(true);
            bleSender.link();
        } else {
            bleClient.disconnect();
        }
    }

    /**
     * 手环配对请求应答
     *
     * @param data byte[]
     */
    private void onPairRequest(byte[] data) {
        mHandler.removeCallbacks(pairTimeOutRunnable);
        PairRequestResponse pairRequestResponse = new PairRequestResponse(data);
        if (pairRequestResponse.isError()) {
            Log.e(TAG, "配对请求返回错误 ");
            bleClient.disconnect();
            return;
        }
        byte[] encryptKey = pairRequestResponse.getEncryptKey();
        byte[] encryptVector = pairRequestResponse.getEncryptVector();
        if (isExchangeEncryptSignatureCorrect(encryptKey, encryptVector, pairRequestResponse.getId(),
                pairRequestResponse.getEncryptSignature())) {
            String deviceUUID = bytesToHex(pairRequestResponse.getId());
            CheckDeviceData checkDeviceData = new CheckDeviceData(deviceUUID, bleState.getLinkedBroadcastData().getMacAddress(),
                    encryptKey, encryptVector);
            bleSender.braceletNeedCheck(checkDeviceData);
        } else {
            Log.e(TAG, "加密认证错误");
            bleClient.disconnect();
        }
    }

    private Runnable pairTimeOutRunnable = new Runnable() {
        @Override
        public void run() {
            bleClient.disconnect();
        }
    };

    /**
     * 启动绑定超时倒计时
     */
    public void launchPairTimeOutClock() {
        mHandler.postDelayed(pairTimeOutRunnable, BleConstant.PAIR_TIME_OUT_TIME);
    }

    /**
     * 收到数据
     *
     * @param receivedData 数据
     */
    private void onReceivedData(byte[] receivedData) {
        byte[] encryptKey;
        byte[] encryptVector;
        CheckDeviceData unconfirmedDeviceData = bleState.getUnconfirmedDeviceData();
        if (unconfirmedDeviceData != null) {
            encryptKey = unconfirmedDeviceData.getKey();
            encryptVector = unconfirmedDeviceData.getVector();
        } else {
            encryptKey = manager.getEncryptKey();
            encryptVector = manager.getEncryptVector();
        }
        if (encryptKey == null || encryptVector == null) {
            return;
        }
        byte[] data = AESUtils.decrypt(encryptKey, receivedData, encryptVector);
        Logger.i("收到信息: " + Arrays.toString(data));
        switch (data[0]) {
            case BluetoothConfig.CODE_SAVE_PAIR_INFO:
                // 确认绑定
                respondCommitPair(data);
                break;
            case BluetoothConfig.CODE_BATTERY_INFO:
                // 电池电量
                respondGetPower(data);
                break;
            case BluetoothConfig.CODE_STOP_MANUAL_SAMPLE:
                // 停止采样
                respondStopManualSample(data);
                break;
            case BluetoothConfig.CODE_START_MANUAL_SAMPLE:
                // 手动采谱
                respondManualSample(data);
                break;
            case BluetoothConfig.CODE_GET_AUTO_SAMPLE_INFO:
                // 自动采样信息
                respondAutoSampleInfo(data);
                break;
            case BluetoothConfig.CODE_GET_STORED_SAMPLE_RET:
                // 自动采样
                respondStoredSampleRet(data);
                break;
            case BluetoothConfig.CODE_DEL_STORED_SAMPLE_RET:
                // 删除自动采样数据
                respondDeleteStoredSample(data);
                break;
            case BluetoothConfig.CODE_GET_SYS_PARA:
                // 获得系统参数应答
                respondGetSystemParam(data);
                break;
            case BluetoothConfig.CODE_SET_SYS_PARA:
                // 设置系统参数应答
                respondSetSystemParam(data);
                break;
            case BluetoothConfig.CODE_GET_FW_INFO:
                // 获取固件信息
                respondGetFirmwareInfo(data);
                break;
            case BluetoothConfig.CODE_FOTA_INFO:
                // 固件升级信息包应答
                respondFotaInfo(data);
                break;
            case BluetoothConfig.CODE_FOTA_DATA:
                // 固件升级文件应答
                respondFotaData(data);
                break;
            case BluetoothConfig.CODE_FOTA_END:
                // 固件升级结束应答
                respondFotaEnd(data);
                break;
            case BluetoothConfig.CODE_REEXE_AUTO_SAMPLE:
                // 重新采样
                respondReExeAutoSample(data);
                break;
            case BluetoothConfig.CODE_RESET_AUTO_SAMPLE:
                // 重置自动采样时间
                respondResetAutoSampleTime(data);
                break;
            case BluetoothConfig.CODE_UPDATE_TIME:
                // 更新时间
                respondUpdateTime(data);
                break;
            case BluetoothConfig.CODE_UNBIND:
                // 解绑
                respondUnPair(data);
                break;
            case BluetoothConfig.CODE_STATUS_UPDATE:
                // 数据有更新
                respondStatusUpdate(data);
                break;
            case BluetoothConfig.CODE_SYNC_BLOOD_PRESSURE:
                // 设置血压值
                respondSetCalculateResult(data);
                break;
            case BluetoothConfig.CODE_SYNC_STEP_DATA:
                // 获取计步数据
                respondStepData(data);
                break;
            case BluetoothConfig.CODE_SYNC_STEP_HISTORY_DATA:
                // 获取历史计步数据（不包括15min内的数据）
                respondHistoryStepData(data);
                break;
            case BluetoothConfig.CODE_CALIBRATE_STEP_DATA:
                // 发送计步数据到手环
                respondCalibrateStepData(data);
                break;
            case BluetoothConfig.CODE_SYNC_STEP_DATA_CTRL:
                respondEnableStepUpdate(data);
                break;
            default:
        }
    }


    /**
     * 确定绑定应答
     *
     * @param data 应答数据
     */
    private void respondCommitPair(byte[] data) {
        mHandler.removeCallbacks(pairTimeOutRunnable);
        CheckDeviceData unconfirmedDeviceData = bleState.getUnconfirmedDeviceData();
        if (data.length == 3 && data[1] == bleState.getGenerator().get() && data[2] == 0x00 && unconfirmedDeviceData != null) {
            savePairInfo(unconfirmedDeviceData.getKey(), unconfirmedDeviceData.getVector(), unconfirmedDeviceData.getId());
            bleSender.pairSuccess();
            bleState.setUnconfirmedDeviceData(null);
        } else {
            bleSender.pairFail();
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }


    /**
     * 获取电量应答
     *
     * @param data 应答数据
     */
    private void respondGetPower(byte[] data) {
        // 电池电量
        if (data.length == 5 && bleState.getGenerator().get() == data[1]) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                // 电量获取成功
                Log.e(TAG, "电量获取成功");
                manager.savePower(data[4] & 0xFF, data[3] & 0xFF);
//                PowerData powerData = new PowerData(data[3] & 0xFF, data[4] & 0xFF);
                bleSender.power();
            } else {
                Log.i(TAG, "获取电量失败 " + BluetoothConfig.getErrorMessage(data[2]));
                bleClient.disconnect();
            }
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 获取停止采样应答
     *
     * @param data 应答数据
     */
    private void respondStopManualSample(byte[] data) {
        if (data.length == 3) {
            if (data[1] == bleState.getGenerator().get() && data[2] == BluetoothConfig.ERROR_NONE) {
                bleState.setSampling(false);
                bleSender.stopSample();
            } else {
                bleClient.disconnect();
            }
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 获取主动采样应答
     *
     * @param data 应答数据
     */
    private void respondManualSample(byte[] data) {
        // 手动采谱
        if (data.length >= 3) {
            ManualSampleData sampleData = new ManualSampleData.Builder().setInProfile400(data);
            int errorCode = sampleData.getErrorCode();
            if (sampleData.getTaq() == ManualMeasureNewOrder.TAG_ECG_PRE ||
                    sampleData.getTaq() == ManualMeasureNewOrder.TAG_ECG_REAL_DATA) {
                if (sampleData.isHaveData()) {
                    bleState.setSampling(true);
                    if (measureEcgData != null) {
                        measureEcgData.addData(sampleData);
                    }
                } else {
                    bleState.setSampling(false);
                    bleSender.sampleEcgError(new ManualEcgError(errorCode));
                }
            } else if (sampleData.getTaq() == ManualMeasureNewOrder.TAG_PRE ||
                    sampleData.getTaq() == ManualMeasureNewOrder.TAG_REAL_DATA) {
                if (sampleData.isHaveData()) {
                    bleState.setSampling(true);
                    if (measurePwData != null) {
                        measurePwData.addData(sampleData);
                    }
                } else {
                    bleState.setSampling(false);
                    bleSender.samplePwError(new ManualPwError(errorCode));
                }
            } else if (sampleData.getTaq() == ManualMeasureNewOrder.TAG_AUTO) {
                if (sampleData.isHaveData()) {
                    bleState.setSampling(true);
                    bleSender.sampleAutoRecognizeData(sampleData);
                } else {
                    bleState.setSampling(false);
                    bleSender.samplePwError(new ManualPwError(errorCode));
                }
            } else if (sampleData.getTaq() == ManualMeasureNewOrder.TAG_PW_RAW_DATA) {
                if (sampleData.isHaveData()) {
                    bleState.setSampling(true);
                    bleSender.samplePwDataWithoutRecognizeData(sampleData);
                } else {
                    bleState.setSampling(false);
                    bleSender.samplePwError(new ManualPwError(errorCode));
                }
            }
        } else {
            bleClient.disconnect();
        }
    }


    /**
     * 获取自动采样信息包
     *
     * @param data 应答数据
     */
    private void respondAutoSampleInfo(byte[] data) {
        if (data.length == 4) {
            // 发生错误
            if (data[1] == bleState.getGenerator().get() && data[2] == BluetoothConfig.ERROR_NONE) {
                if (data[3] > 0) {
                    bleOrder.getStoredAutoPwData();
                    bleSender.startReceivingAutoPwData();
                } else {
                    Log.i(TAG, "获取自动采样数据完成 ");
                    bleState.setSampling(false);
                    bleSender.stopReceivingAutoPwData();
                }
                manager.saveAutoPWSampleTime(Calendar.getInstance().getTimeInMillis());
            } else {
                bleClient.disconnect();
            }
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 获取采样应答
     *
     * @param data 应答数据
     */
    private void respondStoredSampleRet(byte[] data) {
        if (data.length >= 2) {
            StoredSampleData.Builder storedSampleDataBuilder = bleState.getStoredSampleDataBuilder();
            if (storedSampleDataBuilder == null) {
                storedSampleDataBuilder = new StoredSampleData.Builder(AUTO_SAMPLE_DOUBLE_POINT_SIZE);
                bleState.setStoredSampleDataBuilder(storedSampleDataBuilder);
            }
            if (data[1] != bleState.getGenerator().get()) {
                bleClient.disconnect();
                return;
            }
            storedSampleDataBuilder.setInProfile400(data);
            if (storedSampleDataBuilder.isError()) {
                Log.e(TAG, "自动采样信息错误 ");
                error();
                return;
            }
            if (storedSampleDataBuilder.isFinish(AUTO_SAMPLE_DOUBLE_POINT_SIZE)) {
                if (storedSampleDataBuilder.isCrcCorrect()) {
                    if (bleState.isAutoDataState()) {
                        Log.e(TAG, "auto sample complete");
                        bleSender.getStoredAutoData(storedSampleDataBuilder.create());
                        bleOrder.deleteStoredData(true);
                    } else {
                        Log.e(TAG, "manual sample complete");
                        bleState.setSampling(false);
                        bleSender.getStoredManualData(storedSampleDataBuilder.create());
                        bleOrder.deleteStoredData(false);
                    }
//                    deleteStoredData(storedSampleData.isAuto());
                } else {
                    Log.e(TAG, "auto sample crc error");
                    bleOrder.deleteStoredData(true);
                }
            }
        } else {
            bleClient.disconnect();
        }
    }

    /**
     * 获取删除自动采样应答
     *
     * @param data 应答数据
     */
    private void respondDeleteStoredSample(byte[] data) {
        if (data.length == 3 && data[1] == bleState.getGenerator().get()) {
            Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
            if (bleState.isAutoDataState()) {
                bleOrder.getAutoSampleInfo();
            } else {
                bleSender.deleteStoredManualSampleDataSuccess();
            }
            bleState.setStoredSampleDataBuilder(null);
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);

    }

    /**
     * 获取系统参数应答
     *
     * @param data 应答数据
     */
    private void respondGetSystemParam(byte[] data) {
        if (data.length >= 4) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                GetSystemParamResponse response = new GetSystemParamResponse();
                response.set(data);
                Log.i(TAG, "respondGetSystemParam: " + response.getSystemParamData());
                if (data[1] == BluetoothConfig.PARAM_HEIGHT_WEIGHT) {
                    HeightWeightData heightWeightData = response.getSystemParamData().getHeightWeightData();
                    bleSender.getHeightAndWeight(heightWeightData);
                } else if (data[1] == BluetoothConfig.PARAM_DISPLAY_PAGE) {
                    DisplayPage displayPage = response.getSystemParamData().getPageDisplayData();
                    bleSender.getDisplayPage(displayPage);
                    manager.setDisplayPage(displayPage);
                } else if (data[1] == BluetoothConfig.PARAM_ALERT_REMINDERS) {
                    List<AlertReminder> reminders = response.getSystemParamData().getReminders();
                    manager.setReminder(reminders);
                    bleSender.getAlertReminders(reminders);
                }
                bleState.setWorking(false);
            } else {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                bleClient.disconnect();
            }
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 设置系统参数应答
     *
     * @param data 应答数据
     */
    private void respondSetSystemParam(byte[] data) {
        if (data.length == 3) {
            if (data[1] == BluetoothConfig.PARAM_ALERT_REMINDERS) {
                if (data[2] == BluetoothConfig.ERROR_NONE) {
                    if (bleState.getReminders() != null) {
                        manager.setReminder(bleState.getReminders());
                    }
                    bleSender.setParamAlertRemindersSuccess();
//                    bleOrder.getAlertReminders();
                } else {
                    Log.e(TAG, "respondSetSystemParam: " + BluetoothConfig.getErrorMessage(data[2]));
                    error();
                }
            } else if (data[1] == BluetoothConfig.PARAM_DISPLAY_PAGE) {
                if (data[2] == BluetoothConfig.ERROR_NONE) {
                    if (bleState.getDisplayPage() != null) {
                        manager.setDisplayPage(bleState.getDisplayPage());
                    }
                    bleSender.setDisplayPageSuccess();
//                    bleOrder.getDisplayPage();
                } else {
                    Log.e(TAG, "respondSetSystemParam: " + BluetoothConfig.getErrorMessage(data[2]));
                    error();
                }
            } else if (data[1] == BluetoothConfig.PARAM_HEIGHT_WEIGHT) {
                if (data[2] == BluetoothConfig.ERROR_NONE) {
                    bleSender.setHeightAndWeightSuccess();
                } else {
                    Log.e(TAG, "respondSetSystemParam: " + BluetoothConfig.getErrorMessage(data[2]));
                    error();
                }
            }
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 状态改变
     *
     * @param data 数据
     */
    private void respondStatusUpdate(byte[] data) {
        if (data.length == 7) {
            byte[] key = manager.getEncryptKey();
            byte[] vector = manager.getEncryptVector();
            if (data[2] == (byte) (key[2] ^ vector[3]) && data[3] == (byte) (key[4] ^ vector[5])) {
                if (data[4] == 0x01) {
                    bleSender.onPowerChange();
                }
                if (data[5] == 0x01) {
                    // 自动采样信息变化
                    bleSender.onAutoDataChange();
                } else {
                    bleSender.noAutoSampleData();
                }

            } else {
                bleClient.disconnect();
            }
        } else {
            bleClient.disconnect();
        }
    }

    /**
     * 解绑
     *
     * @param data 应答数据
     */
    private void respondUnPair(byte[] data) {
        if (data.length == 3 && data[0] == BluetoothConfig.CODE_UNBIND && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                Log.i(TAG, "解绑成功");
                bleSender.unPairSuccess();
                bleClient.disconnect();
            } else {
                error();
            }
        } else {
            error();
        }
        bleState.setWorking(false);

    }

    /**
     * 更新时间
     *
     * @param data 应答数据
     */
    private void respondUpdateTime(byte[] data) {
        // 更新时间
        if (data.length == 3 && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                Log.i(TAG, "更新时间成功");
                bleSender.setTimeSuccess();
            } else {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            error();
        }
        bleState.setWorking(false);

    }

    /**
     * 重置自动采样时间
     *
     * @param data 应答数据
     */
    private void respondResetAutoSampleTime(byte[] data) {
        // 重置自动采样时间
        if (data.length == 3 && data[0] == BluetoothConfig.CODE_RESET_AUTO_SAMPLE &&
                data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                Log.i(TAG, "设置自动采样时间成功");
                bleSender.resetAutoSampleTimeSuccess();
            } else {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            error();
        }
        bleState.setWorking(false);

    }

    /**
     * 重新自动采样一次
     *
     * @param data 应答数据
     */
    private void respondReExeAutoSample(byte[] data) {
        // 重新采样
        if (data.length == 3 && data[0] == BluetoothConfig.CODE_REEXE_AUTO_SAMPLE
                && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                Log.i(TAG, "重新自动采样执行成功");
                bleSender.setSampleAgainSuccess();
            } else {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            error();
        }
        bleState.setWorking(false);

    }

    /**
     * 发送固件信息信息包结束
     *
     * @param data 应答数据
     */
    private void respondFotaEnd(byte[] data) {
        // 固件升级结束应答
        if (data.length == 3 && data[0] == BluetoothConfig.CODE_FOTA_END) {
            if (data[1] == bleState.getGenerator().get() && data[2] == BluetoothConfig.ERROR_NONE) {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                UpgradeFirmwareManager upgradeFileManager = bleState.getUpgradeFileManager();
                bleSender.upgrade(new FirmStateData(FirmStateData.END, upgradeFileManager.getTotalPkgNumber(),
                        upgradeFileManager.getTotalPkgNumber()));
                bleState.setUpgrading(false);
            } else {
                error();
            }
        } else {
            error();
        }
        bleState.setWorking(false);

    }

    /**
     * 发送固件信息信息包数据
     *
     * @param data 应答数据
     */
    private void respondFotaData(byte[] data) {
        // 固件升级文件应答
        if (data.length == 3 && data[0] == BluetoothConfig.CODE_FOTA_DATA) {
            if (data[1] == bleState.getGenerator().get() && data[2] == BluetoothConfig.ERROR_NONE) {
                UpgradeFirmwareManager upgradeFileManager = bleState.getUpgradeFileManager();
                if (upgradeFileManager != null) {
                    bleSender.upgrade(new FirmStateData(FirmStateData.CONTINUE, upgradeFileManager.getCurrentIndex(), upgradeFileManager.getTotalPkgNumber()));
                    bleState.setUpgrading(true);
                }
                if (!bleState.isCancelUpgrading()) {
                    if (upgradeFileManager != null && upgradeFileManager.hasNextBody()) {
                        bleOrder.upgradeBody();
                    } else {
                        bleOrder.upgradeComplete();
                    }
                } else {
                    bleSender.upgradeCancel();
                }
            } else {
                error();
            }
        } else {
            error();
        }
    }

    /**
     * 发送固件信息信息包应答
     *
     * @param data 应答数据
     */
    private void respondFotaInfo(byte[] data) {
        // 固件升级信息包应答
        if (data.length == 3 && data[0] == BluetoothConfig.CODE_FOTA_INFO) {
            if (data[2] == BluetoothConfig.ERROR_NONE && data[1] == bleState.getGenerator().get()) {
                bleSender.upgrade(new FirmStateData(FirmStateData.START, 0,
                        bleState.getUpgradeFileManager().getTotalPkgNumber()));
                bleState.setUpgrading(true);
                if (!bleState.isCancelUpgrading()) {
                    bleOrder.upgradeBody();
                } else {
                    bleSender.upgradeCancel();
                }
            } else {
                error();
            }
        } else {
            error();
        }
    }

    /**
     * 设置血压
     *
     * @param data 数据
     */
    private void respondSetCalculateResult(byte[] data) {
        if (data.length == 3 && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                bleSender.setBloodPressureComplete();
            } else {
                Log.e(TAG, BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            Log.e(TAG, "设置血压: 格式错误 ");
            error();
        }
        bleState.setWorking(false);

    }

    /**
     * 获取固件信息
     *
     * @param data 应答数据
     */
    private void respondGetFirmwareInfo(byte[] data) {
        if (data.length == 7 && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                FirmwareInfoData firmwareInfoData = new FirmwareInfoData();
                firmwareInfoData.mirror = data[3];
                firmwareInfoData.version = new int[]{data[4] & 0xFF, data[5] & 0xFF, data[6] & 0xFF};
                bleSender.getFirmwareInfo(firmwareInfoData);
                Log.i(TAG, "获取固件信息: " + firmwareInfoData.toString());
                manager.saveDeviceFirmwareVersion(firmwareInfoData.version);
            } else {
                Log.i(TAG, "获取固件信息错误 " + BluetoothConfig.getErrorMessage(data[2]));
                bleClient.disconnect();
            }
        } else {
            bleClient.disconnect();
        }
        bleState.setWorking(false);

    }

    /**
     * 获取计步数据
     *
     * @param data 数据
     */
    private void respondStepData(byte[] data) {
        if (data.length == 18 && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                CurrentStepData currentStepData = new CurrentStepData();
                int hour = (data[3] & 0xFF) + ((data[4] & 0xFF) << 8) + ((data[5] & 0xFF) << 16) + ((data[6] & 0xFF) << 24);
                int quarterOffset = data[7] & 0xFF;
                int quarterStep = (data[8] & 0xFF) + ((data[9] & 0xFF) << 8) + ((data[10] & 0xFF) << 16) + ((data[11] & 0xF) << 24);
                int quarterMin = (data[11] >> 8) & 0xF;
                int step = (data[12] & 0xFF) + ((data[13] & 0xFF) << 8) + ((data[14] & 0xFF) << 16) + ((data[15] & 0xFF) << 24);
                int min = (data[16] & 0xFF) + ((data[17] & 0xFF) << 8);
                currentStepData.setHour(hour);
                currentStepData.setQuarterOffset(quarterOffset);
                currentStepData.setQuarterStep(quarterStep);
                currentStepData.setQuarterMinute(quarterMin);
                currentStepData.setDayStep(step);
                currentStepData.setDayMinute(min);
                bleSender.currentStep(currentStepData);
            } else {
                Log.e(TAG, "获取步数错误 " + BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {

            bleSender.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 获取历史计步数据
     *
     * @param data 数据
     */
    private void respondHistoryStepData(byte[] data) {
        if (data.length >= 3 && data[1] == bleState.getGenerator().get()) {
            if (data.length >= 4 && (data[3] & 0xFF) * 20 + 4 != data.length) {
                Log.e(TAG, "获取历史步数: 包大小错误");
                error();
                return;
            }
            if (data[2] == BluetoothConfig.ERROR_NONE && data.length >= 4) {
                StepHistory.Builder stepHistoryBuilder = bleState.getStepHistoryBuilder();
                if (stepHistoryBuilder == null) {
                    stepHistoryBuilder = new StepHistory.Builder();
                }
                stepHistoryBuilder.setInProfile400(data);
                bleState.setStepHistoryBuilder(stepHistoryBuilder);
            } else if (data[2] == BluetoothConfig.ERROR_END_OF_STREAM && data.length >= 4) {
                StepHistory.Builder stepHistoryBuilder = bleState.getStepHistoryBuilder();
                if (stepHistoryBuilder == null) {
                    stepHistoryBuilder = new StepHistory.Builder();
                }
                stepHistoryBuilder.setInProfile400(data);
                Log.e(TAG, "发送计步数据 ");
                bleSender.stepHistory(stepHistoryBuilder.create());
                bleState.setWorking(false);
                bleState.setStepHistoryBuilder(null);
            } else {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            Log.e(TAG, "获取历史步数失败");
            bleClient.disconnect();
        }
    }

    /**
     * 发送数据到手环应答
     *
     * @param data 数据
     */
    private void respondCalibrateStepData(byte[] data) {
        if (data.length == 3 && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                manager.setIsStepHistorySyncToBracelet(true);
                bleSender.setHistoryStepSuccess();
                Log.i(TAG, "同步计步数据成功");
            } else {
                Log.e(TAG, "同步计步失败:" + BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            Log.i(TAG, "respondCalibrateStepData: error");
            bleClient.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 开启计步更新应答
     *
     * @param data 应答数据
     */
    private void respondEnableStepUpdate(byte[] data) {
        if (data.length == 3 && data[1] == bleState.getGenerator().get()) {
            if (data[2] == BluetoothConfig.ERROR_NONE) {
                Log.i(TAG, "开启或关闭计步更新成功");
                bleSender.setStepUpdateSuccess();
            } else {
                Log.i(TAG, BluetoothConfig.getErrorMessage(data[2]));
                error();
            }
        } else {
            Log.e(TAG, "开启计步更新失败");
            bleSender.disconnect();
        }
        bleState.setWorking(false);
    }

    /**
     * 获取普通密钥
     *
     * @return 密钥
     */
    private byte[] getNormalEncryptKey() {
        byte[] address;
        if (manager.isPaired()) {
            address = bleOrder.getMacBytes();
        } else {
            BroadcastData linkedBroadcastData = bleState.getLinkedBroadcastData();
            address = linkedBroadcastData.getMacAddressBytes();
        }
        byte[] key = new byte[16];
        System.arraycopy(BluetoothConfig.ENCRYPT_FIXED_CODE, 0, key, 0, 7);
        key[7] = address[0];
        System.arraycopy(BluetoothConfig.ENCRYPT_FIXED_CODE, 0, key, 8, 7);
        key[15] = address[2];
        return key;
    }

    /**
     * 获取普通加密向量
     *
     * @return 向量
     */
    private byte[] getNormalEncryptVector() {
        byte[] address;
        int pairCode;
        if (manager.isPaired()) {
            address = bleOrder.getMacBytes();
            pairCode = manager.getCodePair();
        } else {
            BroadcastData linkedBroadcastData = bleState.getLinkedBroadcastData();
            address = linkedBroadcastData.getMacAddressBytes();
            pairCode = linkedBroadcastData.getPairCode();
        }
        byte[] vector = new byte[16];
        System.arraycopy(BluetoothConfig.ENCRYPT_FIXED_CODE, 0, vector, 0, 7);
        vector[7] = address[1];
        System.arraycopy(BluetoothConfig.ENCRYPT_FIXED_CODE, 0, vector, 8, 7);
        vector[15] = (byte) (pairCode & 0xFF);
        return vector;
    }

    /**
     * 交换密钥签名是否正确
     *
     * @param encryptKey       密钥
     * @param encryptVector    向量
     * @param encryptSignature 签名
     * @return boolean
     */
    private boolean isExchangeEncryptSignatureCorrect(byte[] encryptKey, byte[] encryptVector, byte[] id, byte[] encryptSignature) {
        if (encryptKey == null || encryptKey.length != 16 || encryptVector == null || id == null || encryptVector.length != 16
                || encryptSignature == null || encryptSignature.length != 4 || id.length != 16) {
            return false;
        }
        byte[] beforeCrc = new byte[48];
        System.arraycopy(encryptKey, 0, beforeCrc, 0, 16);
        System.arraycopy(encryptVector, 0, beforeCrc, 16, 16);
        System.arraycopy(id, 0, beforeCrc, 32, 16);
        byte[] crcResult = intToByteArray(getCRC32(beforeCrc));
        return crcResult[0] == encryptSignature[0] && crcResult[1] == encryptSignature[1] &&
                crcResult[2] == encryptSignature[2] && crcResult[3] == encryptSignature[3];
    }

    private void error() {
        bleState.setSampling(false);
        bleState.setUpgrading(false);
        bleClient.disconnect();
    }

    /**
     * int 转换为byte
     *
     * @param i long
     * @return 0 低位 4 高位
     */
    private byte[] intToByteArray(long i) {
        byte[] result = new byte[4];
        result[3] = (byte) ((i >> 24) & 0xFF);
        result[2] = (byte) ((i >> 16) & 0xFF);
        result[1] = (byte) ((i >> 8) & 0xFF);
        result[0] = (byte) (i & 0xFF);
        return result;
    }

    /**
     * 获得crc校验结果
     *
     * @param data 数据
     * @return 校验值
     */
    private long getCRC32(byte[] data) {
        CRC32 crc32 = new CRC32();
        crc32.update(data);
        return crc32.getValue();
    }

    private static String bytesToHex(byte[] src) {
        if (src == null || src.length < 16) {
            return null;
        }

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            builder.append(byteToHex(src[i]));
        }
        builder.append("-");
        for (int i = 4; i < 6; i++) {
            builder.append(byteToHex(src[i]));
        }
        builder.append("-");
        for (int i = 6; i < 8; i++) {
            builder.append(byteToHex(src[i]));
        }
        builder.append("-");
        for (int i = 8; i < 10; i++) {
            builder.append(byteToHex(src[i]));
        }
        builder.append("-");
        for (int i = 10; i < 16; i++) {
            builder.append(byteToHex(src[i]));
        }
        return builder.toString();
    }

    private static String byteToHex(byte b) {
        String string = Integer.toHexString(b & 0xFF);
        if (string.length() < 2) {
            string = "0" + string;
        }
        return string;
    }

}
