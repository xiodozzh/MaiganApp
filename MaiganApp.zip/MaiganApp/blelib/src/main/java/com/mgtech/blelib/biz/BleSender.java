package com.mgtech.blelib.biz;

import com.mgtech.blelib.constant.BleStatusConstant;
import com.mgtech.blelib.constant.BleConstant;
import com.mgtech.blelib.entity.AlertReminder;
import com.mgtech.blelib.entity.BluetoothOrder;
import com.mgtech.blelib.entity.BroadcastData;
import com.mgtech.blelib.entity.CheckDeviceData;
import com.mgtech.blelib.entity.CurrentStepData;
import com.mgtech.blelib.entity.FirmStateData;
import com.mgtech.blelib.entity.FirmwareInfoData;
import com.mgtech.blelib.entity.HeightWeightData;
import com.mgtech.blelib.entity.ManualEcgError;
import com.mgtech.blelib.entity.ManualPwError;
import com.mgtech.blelib.entity.ManualSampleData;
import com.mgtech.blelib.entity.SampleCompleteData;
import com.mgtech.blelib.entity.StatusDataEvent;
import com.mgtech.blelib.entity.StepHistory;
import com.mgtech.blelib.entity.StopMeasureData;
import com.mgtech.blelib.entity.StoredSampleData;
import com.mgtech.blelib.entity.DisplayPage;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * @author zhaixiang
 */
public class BleSender {
    private BleCenter bleCenter;

    BleSender(BleCenter bleCenter) {
        this.bleCenter = bleCenter;
    }

    public void sendBroadcast(BroadcastData broadcastData) {
        EventBus.getDefault().post(broadcastData);
    }

    public void sendPairCodeDifferent() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_PAIR_CODE_DIFFERENT));
    }

    public void braceletNeedCheck(CheckDeviceData data) {
        EventBus.getDefault().post(data);
    }

    public void startVerify() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_VERIFING));
    }

    public void connected() {
        bleCenter.clearTask();
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_CONNECTED));
    }

    public void link() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_LINK));
        bleCenter.initLinkTask();
    }

    public void pairSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_PAIR_SUCCESS));
        bleCenter.initPairTask();
    }

    public void pairFail() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_PAIR_FAIL));
    }

    public void disconnect() {
        bleCenter.clearTask();
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_DISCONNECTED));
    }


    public void power() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_GET_POWER_SUCCESS));
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void sampleAutoRecognizeData(ManualSampleData data) {
        EventBus.getDefault().post(data.getManualPwData());
    }

    public void samplePwDataWithoutRecognizeData(ManualSampleData data) {
        EventBus.getDefault().post(data.getManualPwData());
    }

    public void samplePwError(ManualPwError error) {
        EventBus.getDefault().post(error);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void sampleEcgError(ManualEcgError error) {
        EventBus.getDefault().post(error);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void stopSample() {
        EventBus.getDefault().post(new StopMeasureData());
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void getStoredManualData(StoredSampleData data) {
        EventBus.getDefault().post(new SampleCompleteData(data.getUnzippedData(),
                data.getCalendar().getTimeInMillis(), false));
    }

    public void getStoredAutoData(StoredSampleData data) {
        EventBus.getDefault().post(new SampleCompleteData(data.getUnzippedData(),
                data.getCalendar().getTimeInMillis(), true));
    }

    public void stopReceivingAutoPwData() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void setBloodPressureComplete() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void unPairSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_UN_PAIR_SUCCESS));
    }

    public void setTimeSuccess() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void resetAutoSampleTimeSuccess() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void setSampleAgainSuccess() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void upgrade(FirmStateData data) {
        EventBus.getDefault().post(data);
    }


    public void upgradeCancel() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void getFirmwareInfo(FirmwareInfoData data) {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void startReceivingAutoPwData() {
    }


    public void deleteStoredManualSampleDataSuccess() {
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

//    public  void getParamData(SystemParamData data) {
//        EventBus.getDefault().post(data);
//        if (bleCenter != null){
//            bleCenter.runNextTask();
//        }
//    }

    public void getDisplayPage(DisplayPage page) {
        EventBus.getDefault().post(page);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void getAlertReminders(List<AlertReminder> data) {
        EventBus.getDefault().post(data);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void getHeightAndWeight(HeightWeightData data) {
        EventBus.getDefault().post(data);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }


    public void setParamAlertRemindersSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_SET_ALERT_REMINDERS_SUCCESS));
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void setDisplayPageSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_SET_DISPLAY_PAGE_SUCCESS));
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void setHeightAndWeightSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_SET_HEIGHT_WEIGHT_SUCCESS));
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }


    public void onPowerChange() {
        if (bleCenter != null) {
            bleCenter.putOrderInQueue(new BluetoothOrder(BleConstant.CODE_GET_POWER));
            bleCenter.runNextTaskWhenNotWorking();
        }
    }

    public void onAutoDataChange() {
        if (bleCenter != null) {
            bleCenter.putOrderInQueue(new BluetoothOrder(BleConstant.CODE_GET_AUTO_MEASURE_INFO));
            bleCenter.runNextTaskWhenNotWorking();
        }
    }

    public void stepHistory(StepHistory stepHistory) {
        EventBus.getDefault().post(stepHistory);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void currentStep(CurrentStepData currentStepData) {
        EventBus.getDefault().post(currentStepData);
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void setStepUpdateSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_ENABLE_STEP_UPDATE));
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void setHistoryStepSuccess() {
        EventBus.getDefault().post(new StatusDataEvent(BleStatusConstant.STATUS_SET_HISTORY_STEP_SUCCESS));
        if (bleCenter != null) {
            bleCenter.runNextTask();
        }
    }

    public void noAutoSampleData() {
        if (bleCenter != null) {
            bleCenter.runNextTaskWhenNotWorking();
        }
    }

}
