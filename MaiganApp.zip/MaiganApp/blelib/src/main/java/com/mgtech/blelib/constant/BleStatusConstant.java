package com.mgtech.blelib.constant;

/**
 *
 * @author zhaixiang
 * @date 2016/7/18
 * 参数
 */
public class BleStatusConstant {
    public static final int PHONE_SCREEN_OFF = 1;
    public static final int PHONE_BACK_HOME = 2;

    public static final int LINK_CONNECTED = 1;
    public static final int LINK_DISCONNECT = 2;

    public static final int STATUS_STOP_SCAN = 1;
    public static final int STATUS_START_SCAN = 2;
    public static final int STATUS_CONNECTED = 3;
    public static final int STATUS_DISCONNECTED = 4;
    public static final int STATUS_WAITING_COMMIT = 5;
    public static final int STATUS_PAIR_SUCCESS = 6;
    public static final int STATUS_PAIR_FAIL = 7;
    public static final int STATUS_PAIRED = 8;
    public static final int STATUS_PAIR_CODE_DIFFERENT = 9;
    public static final int STATUS_HAVE_AUTO_SAMPLE_DATA = 11;
    public static final int STATUS_HAVE_NO_AUTO_SAMPLE_DATA = 12;
    public static final int STATUS_SLEEP = 13;
    public static final int STATUS_GET_POWER_SUCCESS = 15;

    public static final int STATUS_PARAM_SET_0 = 16;
    public static final int STATUS_PARAM_SET_1 = 17;
    public static final int STATUS_PARAM_SET_2 = 18;
    public static final int STATUS_PARAM_SET_3 = 19;
    public static final int STATUS_SET_ALERT_REMINDERS_SUCCESS = 20;
    public static final int STATUS_SET_DISPLAY_PAGE_SUCCESS = 21;
    public static final int STATUS_RE_SCAN = 22;
    public static final int STATUS_GET_FIRMWARE_SUCCESS = 23;
    public static final int STATUS_PARAM_GET_0 = 24;

    public static final int STATUS_PAIR_REQUEST = 32;
    public static final int STATUS_UN_PAIR_SUCCESS = 33;
    public static final int STATUS_MEASURE_ERROR_LOW_POWER = 34;
    public static final int STATUS_MEASURE_ERROR_NOT_WEARING= 35;
    public static final int STATUS_RESET_AUTO_TIME = 37;
    public static final int STATUS_ENABLE_STEP_UPDATE = 38;
    public static final int STATUS_DISABLE_STEP_UPDATE = 39;
    public static final int STATUS_SET_HISTORY_STEP_SUCCESS = 40;
    public static final int STATUS_SET_BLOOD_PRESSURE = 41;

    public static final int STATUS_MEASURE_ECG_1 = 44;
    public static final int STATUS_MEASURE_ECG_2 = 45;
    public static final int STATUS_PARAM_SET_FAIL = 46;
    public static final int STATUS_LINK = 47;
    public static final int STATUS_VERIFING = 48;
    public static final int STATUS_SET_HEIGHT_WEIGHT_SUCCESS = 49;

    public static final int WARNING_MULTIPLE_DEVICE = 1;
}
