package com.mgtech.blelib.entity;

/**
 * Created by zhaixiang on 2018/3/8.
 * 连接状态
 */

public class LinkStatusData {
    private int status;

    public LinkStatusData(int status) {
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LinkStatusData{" +
                "status=" + status +
                '}';
    }
}
