package com.mgtech.blelib.biz;

import android.content.Context;

import com.mgtech.blelib.entity.BluetoothOrder;

public interface IBizController {
    boolean isBleOn();

    boolean isReady();

    void link();

    void pair();

    void disconnect();

    void stopScan();

    void disconnectIfNotWorking();

    void addOrder(BluetoothOrder order);

}
