package com.mgtech.blelib.entity;

/**
 * Created by zhaixiang on 2018/3/8.
 */

public class StopMeasureData {
}
