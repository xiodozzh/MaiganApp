//package com.mgtech.blelib.entity;
//
//public class AutoMeasureRemindTimeItem {
//    private boolean enable;
//    // bit 0 周日，bit 6 周六
//    private int repeat;
//
//    private int startHour;
//
//    private int startMinute;
//
//    private int period;
//
//    public boolean isEnable() {
//        return enable;
//    }
//
//    public void setEnable(boolean enable) {
//        this.enable = enable;
//    }
//
//    public int getRepeat() {
//        return repeat;
//    }
//
//    public void setRepeat(int repeat) {
//        this.repeat = repeat;
//    }
//
//    public int getStartHour() {
//        return startHour;
//    }
//
//    public void setStartHour(int startHour) {
//        this.startHour = startHour;
//    }
//
//    public int getStartMinute() {
//        return startMinute;
//    }
//
//    public void setStartMinute(int startMinute) {
//        this.startMinute = startMinute;
//    }
//
//    public int getPeriod() {
//        return period;
//    }
//
//    public void setPeriod(int period) {
//        this.period = period;
//    }
//}
