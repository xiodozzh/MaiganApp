package com.mgtech.blelib.biz;


import android.util.Log;

import com.mgtech.blelib.entity.AlertReminder;
import com.mgtech.blelib.entity.BroadcastData;
import com.mgtech.blelib.entity.CheckDeviceData;
import com.mgtech.blelib.entity.DisplayPage;
import com.mgtech.blelib.entity.HeightWeightData;
import com.mgtech.blelib.entity.StepHistory;
import com.mgtech.blelib.entity.StoredSampleData;
import com.mgtech.blelib.utils.UpgradeFirmwareManager;

import java.util.List;

/**
 * @author zhaixiang
 */
public class BleState {
    private BroadcastData linkedBroadcastData;
    private RandomCodeGenerator generator;
    private CheckDeviceData unconfirmedDeviceData;
    /**
     * 计步历史数据
     */
    private StepHistory.Builder stepHistoryBuilder;
    private StoredSampleData.Builder storedSampleDataBuilder;
    private UpgradeFirmwareManager upgradeFileManager;
    private boolean cancelUpgrading;
    private boolean autoDataState = false;
    private boolean sampling;
    private boolean upgrading;
    private boolean scanning;
    private boolean ready;
    private boolean connected;
    private boolean working;

    private List<AlertReminder> reminders;
    private DisplayPage displayPage;
    private HeightWeightData heightWeightData;

    public BleState() {
        this.generator = RandomCodeGenerator.getInstance();
    }

    public void clear(){
        stepHistoryBuilder = null;
        storedSampleDataBuilder = null;
        upgradeFileManager = null;
        reminders = null;
        displayPage = null;
        heightWeightData = null;
    }

    public BroadcastData getLinkedBroadcastData() {
        return linkedBroadcastData;
    }

    public void setLinkedBroadcastData(BroadcastData linkedBroadcastData) {
        this.linkedBroadcastData = linkedBroadcastData;
    }

    public RandomCodeGenerator getGenerator() {
        return generator;
    }

    public void setGenerator(RandomCodeGenerator generator) {
        this.generator = generator;
    }

    public CheckDeviceData getUnconfirmedDeviceData() {
        return unconfirmedDeviceData;
    }

    public void setUnconfirmedDeviceData(CheckDeviceData unconfirmedDeviceData) {
        this.unconfirmedDeviceData = unconfirmedDeviceData;
    }

    public StepHistory.Builder getStepHistoryBuilder() {
        return stepHistoryBuilder;
    }

    public void setStepHistoryBuilder(StepHistory.Builder stepHistoryBuilder) {
        this.stepHistoryBuilder = stepHistoryBuilder;
    }

    public StoredSampleData.Builder getStoredSampleDataBuilder() {
        return storedSampleDataBuilder;
    }

    public void setStoredSampleDataBuilder(StoredSampleData.Builder storedSampleDataBuilder) {
        this.storedSampleDataBuilder = storedSampleDataBuilder;
    }

    public UpgradeFirmwareManager getUpgradeFileManager() {
        return upgradeFileManager;
    }

    public void setUpgradeFileManager(UpgradeFirmwareManager upgradeFileManager) {
        this.upgradeFileManager = upgradeFileManager;
    }

    public boolean isCancelUpgrading() {
        return cancelUpgrading;
    }

    public void setCancelUpgrading(boolean cancelUpgrading) {
        this.cancelUpgrading = cancelUpgrading;
    }

    public boolean isAutoDataState() {
        return autoDataState;
    }

    public void setAutoDataState(boolean autoDataState) {
        this.autoDataState = autoDataState;
    }

    public boolean isSampling() {
        return sampling;
    }

    public void setSampling(boolean sampling) {
        this.sampling = sampling;
    }

    public boolean isUpgrading() {
        return upgrading;
    }

    public void setUpgrading(boolean upgrading) {
        this.upgrading = upgrading;
    }

    public boolean isScanning() {
        return scanning;
    }

    public void setScanning(boolean scanning) {
        this.scanning = scanning;
    }

    public boolean isReady() {
        return ready;
    }

    public void setReady(boolean ready) {
        this.ready = ready;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public boolean isWorking() {
        return working;
    }

    public void setWorking(boolean working) {
        Log.i("bleState", "setWorking: "+ working);
        this.working = working;
    }

    public List<AlertReminder> getReminders() {
        return reminders;
    }

    public void setReminders(List<AlertReminder> reminders) {
        this.reminders = reminders;
    }

    public DisplayPage getDisplayPage() {
        return displayPage;
    }

    public void setDisplayPage(DisplayPage displayPage) {
        this.displayPage = displayPage;
    }

    public HeightWeightData getHeightWeightData() {
        return heightWeightData;
    }

    public void setHeightWeightData(HeightWeightData heightWeightData) {
        this.heightWeightData = heightWeightData;
    }

}
