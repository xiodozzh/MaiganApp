package com.mgtech.blelib.utils;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.mgtech.blelib.constant.BleConstant;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by zhaixiang on 2017/12/13.
 * 工具
 */

public class Utils {

    public static short[] unzipData(byte[] rawData, int offset) {
        int length = rawData.length;
        short[] data = new short[(length - offset) / 3 * 2];
        int[] temple = new int[(length - offset) / 3];
        for (int i = offset; i < length; i++) {
            int row = (i - offset) / 3;
            int column = (i - offset) % 3;
            temple[row] += (rawData[i] & 0x0000FF) << (8 * column);
        }
        for (int i = 0; i < temple.length; i++) {
            data[i * 2] = (short) (temple[i] & 0xFFF);
            data[i * 2 + 1] = (short) (temple[i] >>> 12);
        }
        return data;
    }

    /**
     * 蓝牙是否打开
     *
     * @return true蓝牙打开，false反之
     */
    public static boolean isBluetoothOpen() {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        return mBluetoothAdapter != null && mBluetoothAdapter.isEnabled();
    }

    /**
     * 返回版本名字
     * 对应build.gradle中的versionName
     *
     * @param context 上下文
     * @return versionName
     */
    public static String getVersionName(Context context) {
        String versionName = "";
        try {
            PackageManager packageManager = context.getPackageManager();
            PackageInfo packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
            versionName = packInfo.versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionName;
    }

    /**
     * 返回版本号
     * 对应build.gradle中的versionCode
     *
     * @param context 上下文
     * @return versionCode
     */
    public static int getVersionCode(Context context) {
        int versionCode = 0;
        try {
            PackageManager packageManager = context.getPackageManager();
            PackageInfo packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
            versionCode = packInfo.versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionCode;
    }


    /**
     * format yyyy-MM-dd
     */
    private static DateFormat format1 = new SimpleDateFormat(BleConstant.DISPLAY_DATE_1, Locale.getDefault());
    /**
     * format yyyy-MM-dd HH:mm:ss
     */
    private static DateFormat format2 = new SimpleDateFormat(BleConstant.DISPLAY_DATE_3, Locale.getDefault());

    static {
        format1.setTimeZone(TimeZone.getTimeZone("UTC"));
        format2.setTimeZone(TimeZone.getTimeZone("UTC"));
    }



    /**
     * 获取时区
     *
     * @return 东8区为+8
     */
    public static int getTimeZone() {
        return TimeZone.getDefault().getRawOffset() / 1000 / 3600;
    }


    public static String localCalendarToFullUTCString(long localTime) {
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTimeInMillis(localTime);
//        calendar.setTimeZone(TimeZone.getTimeZone("UTC"));
//        DateFormat format = new SimpleDateFormat(BleConstant.DISPLAY_DATE_1,Locale.getDefault());
//        format.setTimeZone(TimeZone.getTimeZone("UTC"));
//        return format.format(new Date(localTime));

        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.setTimeInMillis(localTime);
//        DateFormat format = new SimpleDateFormat(BleConstant.DISPLAY_DATE_5,Locale.getDefault());
        return format2.format(new Date(localTime));
    }

    public static boolean isEnglish(){
        return !Locale.getDefault().getLanguage().equals(Locale.CHINESE.getLanguage());
    }

}
