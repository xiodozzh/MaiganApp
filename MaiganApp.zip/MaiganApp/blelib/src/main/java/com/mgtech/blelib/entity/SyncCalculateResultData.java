package com.mgtech.blelib.entity;

import android.util.SparseArray;

import com.mgtech.blelib.constant.BleConstant;

public class SyncCalculateResultData {
    private SparseArray<ResultItem> array;

    public SyncCalculateResultData() {
        array = new SparseArray<>();
    }

    public void setHr(int heartRate,int level){
        array.setValueAt(BleConstant.INDEX_HR,new ResultItem(heartRate,level));
    }

    public void setPs(int ps,int level){
        array.setValueAt(BleConstant.INDEX_PS,new ResultItem(ps,level));
    }

    public void setPd(int pd,int level){
        array.setValueAt(BleConstant.INDEX_PD,new ResultItem(pd,level));
    }

    public void setV0(float v0,int level){
        array.setValueAt(BleConstant.INDEX_V0,new ResultItem(Math.round(v0 * 100),level));
    }

    public int getHr(){
        return array.get(BleConstant.INDEX_HR).value;
    }

    public int getHrLevel(){
        return array.get(BleConstant.INDEX_HR).level;
    }

    public int getPs(){
        return array.get(BleConstant.INDEX_PS).value;
    }

    public int getPsLevel(){
        return array.get(BleConstant.INDEX_PS).level;
    }

    public int getPd(){
        return array.get(BleConstant.INDEX_PD).value;
    }

    public int getPdLevel(){
        return array.get(BleConstant.INDEX_PD).level;
    }

    public float getV0(){
        return array.get(BleConstant.INDEX_V0).value /100f;
    }

    public float getV0Level(){
        return array.get(BleConstant.INDEX_V0).level;
    }

    public static class ResultItem{
        private int value;
        private int level;

        ResultItem(int value, int level) {
            this.value = value;
            this.level = level;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public int getLevel() {
            return level;
        }

        public void setLevel(int level) {
            this.level = level;
        }
    }
}
