//package com.mgtech.blelib.entity;
//
//public class PageDisplayData {
//    public static final int ON = SystemParamData.ON;
//    public static final int OFF = SystemParamData.OFF;
//
//    public static final int DATE_SIMPLE = SystemParamData.DATE_SIMPLE;
//    public static final int DATE_COMPLEX = SystemParamData.DATE_COMPLEX;
//
//    private int bpPageDisplay = ON;
//    private int hrPageDisplay = ON;
//    private int v0PageDisplay = ON;
//    private int stepPageDisplay = ON;
//    private int distancePageDisplay = ON;
//    private int heatPageDisplay = ON;
//    private int powerPageDisplay = ON;
//
//
//
//    public int getBpPageDisplay() {
//        return bpPageDisplay;
//    }
//
//    public void setBpPageDisplay(int bpPageDisplay) {
//        this.bpPageDisplay = bpPageDisplay;
//    }
//
//    public int getStepPageDisplay() {
//        return stepPageDisplay;
//    }
//
//    public void setStepPageDisplay(int stepPageDisplay) {
//        this.stepPageDisplay = stepPageDisplay;
//    }
//
//    public int getDistancePageDisplay() {
//        return distancePageDisplay;
//    }
//
//    public void setDistancePageDisplay(int distancePageDisplay) {
//        this.distancePageDisplay = distancePageDisplay;
//    }
//
//    public int getHeatPageDisplay() {
//        return heatPageDisplay;
//    }
//
//    public void setHeatPageDisplay(int heatPageDisplay) {
//        this.heatPageDisplay = heatPageDisplay;
//    }
//
//    public int getPowerPageDisplay() {
//        return powerPageDisplay;
//    }
//
//    public void setPowerPageDisplay(int powerPageDisplay) {
//        this.powerPageDisplay = powerPageDisplay;
//    }
//
//    public int getHrPageDisplay() {
//        return hrPageDisplay;
//    }
//
//    public void setHrPageDisplay(int hrPageDisplay) {
//        this.hrPageDisplay = hrPageDisplay;
//    }
//
//    public int getV0PageDisplay() {
//        return v0PageDisplay;
//    }
//
//    public void setV0PageDisplay(int v0PageDisplay) {
//        this.v0PageDisplay = v0PageDisplay;
//    }
//}
