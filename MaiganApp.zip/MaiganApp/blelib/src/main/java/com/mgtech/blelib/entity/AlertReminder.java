package com.mgtech.blelib.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author zhaixiang
 */
public class AlertReminder implements Parcelable {
    public static final int MAX_NUMBER = 5;

    private int reminderWeek;
    private int reminderStartHour;
    private int reminderStartMinute;
    private int reminderSpanTime;
    private boolean reminderEnable;

    public AlertReminder() {
    }

    protected AlertReminder(Parcel in) {
        reminderWeek = in.readInt();
        reminderStartHour = in.readInt();
        reminderStartMinute = in.readInt();
        reminderSpanTime = in.readInt();
        reminderEnable = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(reminderWeek);
        dest.writeInt(reminderStartHour);
        dest.writeInt(reminderStartMinute);
        dest.writeInt(reminderSpanTime);
        dest.writeByte((byte) (reminderEnable ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AlertReminder> CREATOR = new Creator<AlertReminder>() {
        @Override
        public AlertReminder createFromParcel(Parcel in) {
            return new AlertReminder(in);
        }

        @Override
        public AlertReminder[] newArray(int size) {
            return new AlertReminder[size];
        }
    };

    public int getReminderWeek() {
        return reminderWeek;
    }

    public void setReminderWeek(int reminderWeek) {
        this.reminderWeek = reminderWeek;
    }

    public int getReminderStartHour() {
        return reminderStartHour;
    }

    public void setReminderStartHour(int reminderStartHour) {
        this.reminderStartHour = reminderStartHour;
    }

    public int getReminderStartMinute() {
        return reminderStartMinute;
    }

    public void setReminderStartMinute(int reminderStartMinute) {
        this.reminderStartMinute = reminderStartMinute;
    }

    public int getReminderSpanTime() {
        return reminderSpanTime;
    }

    public void setReminderSpanTime(int reminderSpanTime) {
        this.reminderSpanTime = reminderSpanTime;
    }

    public boolean isReminderEnable() {
        return reminderEnable;
    }

    public void setReminderEnable(boolean reminderEnable) {
        this.reminderEnable = reminderEnable;
    }



    @Override
    public String toString() {
        return "AlertReminder{" +
                "reminderWeek=" + reminderWeek +
                ", reminderStartHour=" + reminderStartHour +
                ", reminderStartMinute=" + reminderStartMinute +
                ", reminderSpanTime=" + reminderSpanTime +
                ", reminderEnable=" + reminderEnable +
                '}';
    }
}
