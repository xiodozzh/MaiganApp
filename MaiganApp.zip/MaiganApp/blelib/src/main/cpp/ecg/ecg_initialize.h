//
// File: ecg_initialize.h
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 18-Aug-2017 19:21:12
//
#ifndef ECG_INITIALIZE_H
#define ECG_INITIALIZE_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "ecg_types.h"

// Function Declarations
extern void ecg_initialize();

#endif

//
// File trailer for ecg_initialize.h
//
// [EOF]
//
