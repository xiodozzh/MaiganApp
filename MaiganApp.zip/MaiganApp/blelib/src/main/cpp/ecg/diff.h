//
// File: diff.h
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 18-Aug-2017 19:21:12
//
#ifndef DIFF_H
#define DIFF_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "ecg_types.h"

// Function Declarations
extern void diff(const emxArray_real_T *x, emxArray_real_T *y);

#endif

//
// File trailer for diff.h
//
// [EOF]
//
