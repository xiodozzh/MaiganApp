//
// File: imodwt.h
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 18-Aug-2017 19:21:12
//
#ifndef IMODWT_H
#define IMODWT_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "ecg_types.h"

// Function Declarations
extern void imodwt(const emxArray_real_T *w, emxArray_real_T *xrec);

#endif

//
// File trailer for imodwt.h
//
// [EOF]
//
