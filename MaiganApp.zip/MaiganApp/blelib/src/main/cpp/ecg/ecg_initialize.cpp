//
// File: ecg_initialize.cpp
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 18-Aug-2017 19:21:12
//

// Include Files
#include "rt_nonfinite.h"
#include "detect_ecg.h"
#include "filter_ecg.h"
#include "ecg_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void ecg_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for ecg_initialize.cpp
//
// [EOF]
//
