package com.mgtech.domain.entity.net.response;

public class BindAccountResponseEntity {

    /**
     * accountGuid :
     */

    private String accountGuid;

    public String getAccountGuid() {
        return accountGuid;
    }

    public void setAccountGuid(String accountGuid) {
        this.accountGuid = accountGuid;
    }
}
