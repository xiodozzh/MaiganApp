//package com.mgtech.domain.entity.net.response;
//
//import com.google.gson.annotations.SerializedName;
//import com.mgtech.domain.utils.NetConstant;
//
///**
// * Created by zhaixiang on 2017/9/5.
// * 自动采谱计算结果
// */
//
//public class AutoMeasureResponseEntity {
////    @SerializedName(NetConstant.FLAG)
////    private String flag;
//    @SerializedName(NetConstant.JSON_CALCULATE_STATUS)
//    private int calculateStatus;
//    @SerializedName(NetConstant.JSON_CALCULATE_MESSAGE)
//    private String calculateMessage;
////    public String getFlag() {
////        return flag;
////    }
////
////    public void setFlag(String flag) {
////        this.flag = flag;
////    }
//
//    public int getCalculateStatus() {
//        return calculateStatus;
//    }
//
//    public void setCalculateStatus(int calculateStatus) {
//        this.calculateStatus = calculateStatus;
//    }
//
//    public String getCalculateMessage() {
//        return calculateMessage;
//    }
//
//    public void setCalculateMessage(String calculateMessage) {
//        this.calculateMessage = calculateMessage;
//    }
//
//    @Override
//    public String toString() {
//        return "AutoMeasureResponseEntity{" +
//                ", calculateStatus=" + calculateStatus +
//                ", calculateMessage='" + calculateMessage + '\'' +
//                '}';
//    }
//}
