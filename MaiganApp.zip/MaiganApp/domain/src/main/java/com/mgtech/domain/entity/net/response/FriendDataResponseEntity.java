package com.mgtech.domain.entity.net.response;

public class FriendDataResponseEntity {

    private long lastMeasureTime;
    private long lastRemindTime;
    private ExceptionResponseEntity lastTimeAbnormalRecord;
    private GetHomeDataResponseEntity.LastDayPWDataBean lastDayPWData;
    private GetHomeDataResponseEntity.LastTimeECGDataBean lastTimeECGData;

    public long getLastMeasureTime() {
        return lastMeasureTime;
    }

    public void setLastMeasureTime(long lastMeasureTime) {
        this.lastMeasureTime = lastMeasureTime;
    }

    public long getLastRemindTime() {
        return lastRemindTime;
    }

    public void setLastRemindTime(long lastRemindTime) {
        this.lastRemindTime = lastRemindTime;
    }

    public ExceptionResponseEntity getLastTimeAbnormalRecord() {
        return lastTimeAbnormalRecord;
    }

    public void setLastTimeAbnormalRecord(ExceptionResponseEntity lastTimeAbnormalRecord) {
        this.lastTimeAbnormalRecord = lastTimeAbnormalRecord;
    }

    public GetHomeDataResponseEntity.LastDayPWDataBean getLastDayPWData() {
        return lastDayPWData;
    }

    public void setLastDayPWData(GetHomeDataResponseEntity.LastDayPWDataBean lastDayPWData) {
        this.lastDayPWData = lastDayPWData;
    }

    public GetHomeDataResponseEntity.LastTimeECGDataBean getLastTimeECGData() {
        return lastTimeECGData;
    }

    public void setLastTimeECGData(GetHomeDataResponseEntity.LastTimeECGDataBean lastTimeECGData) {
        this.lastTimeECGData = lastTimeECGData;
    }

    @Override
    public String toString() {
        return "FriendDataResponseEntity{" +
                "lastMeasureTime=" + lastMeasureTime +
                ", lastRemindTime=" + lastRemindTime +
                ", lastTimeAbnormalRecord=" + lastTimeAbnormalRecord +
                ", lastDayPWData=" + lastDayPWData +
                ", lastTimeECGData=" + lastTimeECGData +
                '}';
    }
}
