//package com.mgtech.domain.entity.socket;
//
//public class ConnectRequestEntity {
//
//
//    /**
//     * req : 0
//     * accountGuid :
//     * accessToken :
//     * deviceId :
//     */
//
//    private int req;
//    private String accountGuid;
//    private String accessToken;
//    private String deviceId;
//
//    public int getReq() {
//        return req;
//    }
//
//    public void setReq(int req) {
//        this.req = req;
//    }
//
//    public String getAccountGuid() {
//        return accountGuid;
//    }
//
//    public void setAccountGuid(String accountGuid) {
//        this.accountGuid = accountGuid;
//    }
//
//    public String getAccessToken() {
//        return accessToken;
//    }
//
//    public void setAccessToken(String accessToken) {
//        this.accessToken = accessToken;
//    }
//
//    public String getDeviceId() {
//        return deviceId;
//    }
//
//    public void setDeviceId(String deviceId) {
//        this.deviceId = deviceId;
//    }
//
//    @Override
//    public String toString() {
//        return "ConnectRequestEntity{" +
//                "req=" + req +
//                ", accountGuid='" + accountGuid + '\'' +
//                ", accessToken='" + accessToken + '\'' +
//                ", deviceId='" + deviceId + '\'' +
//                '}';
//    }
//}
