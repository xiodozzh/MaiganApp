package com.mgtech.domain.exception;

/**
 * Created by zhaixiang on 2016/6/12.
 */
public class NullIndicatorExeception extends RuntimeException {
    public NullIndicatorExeception(String message){
        super(message);
    }
}
