package com.mgtech.domain.entity.net;

/**
 * Created by zhaixiang on 2017/5/2.
 * 生成请求指令
 */

public interface RequestString {
    String getString();
}
