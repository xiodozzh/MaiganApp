package com.mgtech.domain.entity.net;

/**
 *
 * @author zhaixiang
 * 请求体
 */

public interface RequestEntity {
    String getUrl();
    String getBody();
}
