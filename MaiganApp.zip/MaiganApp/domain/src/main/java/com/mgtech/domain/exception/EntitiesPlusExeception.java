package com.mgtech.domain.exception;

/**
 * Created by zhaixiang on 2016/5/27.
 */
public class EntitiesPlusExeception extends RuntimeException {
    public EntitiesPlusExeception(String message) {
        super(message);
    }
}
