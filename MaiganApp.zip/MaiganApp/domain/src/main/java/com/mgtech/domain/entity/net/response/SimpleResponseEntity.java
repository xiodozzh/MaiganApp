package com.mgtech.domain.entity.net.response;

/**
 * Created by zhaixiang on 2017/1/6.
 * 简单信息
 */

public class SimpleResponseEntity extends ResponseEntity{
}
