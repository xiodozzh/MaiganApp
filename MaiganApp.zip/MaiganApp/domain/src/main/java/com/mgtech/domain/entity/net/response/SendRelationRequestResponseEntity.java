package com.mgtech.domain.entity.net.response;

import com.google.gson.annotations.SerializedName;
import com.mgtech.domain.utils.NetConstant;

/**
 * Created by zhaixiang on 2017/3/9.
 * 关注请求
 */

public class SendRelationRequestResponseEntity extends ResponseEntity{
}
