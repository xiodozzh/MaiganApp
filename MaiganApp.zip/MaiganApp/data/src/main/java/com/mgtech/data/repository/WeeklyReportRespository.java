package com.mgtech.data.repository;

import android.content.Context;

import com.mgtech.data.net.retrofit.RetrofitFactory;
import com.mgtech.data.net.retrofit.WeeklyReportApi;
import com.mgtech.domain.entity.net.request.GetWeeklyReportRequestEntity;
import com.mgtech.domain.entity.net.response.NetResponseEntity;
import com.mgtech.domain.entity.net.response.WeeklyReportResponseEntity;
import com.mgtech.domain.repository.NetRepository;
import com.mgtech.domain.utils.HttpApi;

import java.util.List;

import rx.Single;

public class WeeklyReportRespository implements NetRepository.WeeklyReport {
    private Context context;
    private WeeklyReportApi api;

    public WeeklyReportRespository(Context context) {
        this.context = context;
        this.api = new RetrofitFactory()
                .setUseToken(true)
                .setBaseUrl(HttpApi.API_BASE_URL)
                .build(context)
                .create(WeeklyReportApi.class);
    }

    @Override
    public Single<NetResponseEntity<List<WeeklyReportResponseEntity>>> getWeeklyReportList(GetWeeklyReportRequestEntity entity,
                                                                                           int cacheType) {
//        Type type = new TypeToken<NetResponseEntity<List<WeeklyReportResponseEntity>>>() {
//        }.getType();
//        return DataStoreFactory.strategy(context, api.getWeeklyReportList(entity.getId(),entity.getPwDataType()),
//                entity, cacheType,type);
        return api.getWeeklyReportList(entity.getId(),entity.getPwDataType());
    }
}
