package com.mgtech.data.repository;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mgtech.data.net.http.NetworkRequest;
import com.mgtech.domain.entity.net.request.BindDeviceRequestEntity;
import com.mgtech.domain.entity.net.request.CheckBraceletRequestEntity;
import com.mgtech.domain.entity.net.request.GetBraceletConfigRequestEntity;
import com.mgtech.domain.entity.net.request.GetDeviceBindInfoRequestEntity;
import com.mgtech.domain.entity.net.request.SetBraceletInfoRequestEntity;
import com.mgtech.domain.entity.net.request.UnbindBraceletRequestEntity;
import com.mgtech.domain.entity.net.response.BraceletConfigEntity;
import com.mgtech.domain.entity.net.response.CheckBraceletResponseEntity;
import com.mgtech.domain.entity.net.response.GetBindInfoResponseEntity;
import com.mgtech.domain.entity.net.response.NetResponseEntity;
import com.mgtech.domain.repository.NetRepository;
import com.mgtech.domain.utils.NetConstant;
import com.mgtech.domain.entity.Mapper;

import java.lang.reflect.Type;
import java.util.List;

import rx.Observable;

/**
 * Created by zhaixiang on 2018/1/24.
 * 网络请求
 */

public class DeviceRepository implements NetRepository.Device {
    private Context context;

    public DeviceRepository(Context context) {
        this.context = context;
    }


    @Override
    public Observable<NetResponseEntity<CheckBraceletResponseEntity>> checkBraceletCopyright(CheckBraceletRequestEntity entity) {
        return NetworkRequest.requestFromNet(context, true, NetworkRequest.POST, entity
                , NetConstant.NO_CACHE, new Mapper<NetResponseEntity<CheckBraceletResponseEntity>>() {
                    @Override
                    public NetResponseEntity<CheckBraceletResponseEntity> mapToEntity(String string) {
                        Type type = new TypeToken<NetResponseEntity<CheckBraceletResponseEntity>>() {
                        }.getType();
                        return new Gson().fromJson(string, type);
                    }
                });
    }

    @Override
    public Observable<NetResponseEntity<BraceletConfigEntity>> bindDevice(BindDeviceRequestEntity entity) {
        return NetworkRequest.requestFromNet(context, true, NetworkRequest.POST, entity
                , NetConstant.NO_CACHE, new Mapper<NetResponseEntity<BraceletConfigEntity>>() {
                    @Override
                    public NetResponseEntity<BraceletConfigEntity> mapToEntity(String string) {
                        Type type = new TypeToken<NetResponseEntity<BraceletConfigEntity>>() {
                        }.getType();
                        return new Gson().fromJson(string, type);
                    }
                });
    }

    @Override
    public Observable<NetResponseEntity> unbindDevice(UnbindBraceletRequestEntity entity) {
        return NetworkRequest.requestFromNet(context, true, NetworkRequest.POST, entity
                , NetConstant.NO_CACHE, new Mapper<NetResponseEntity>() {
                    @Override
                    public NetResponseEntity mapToEntity(String string) {
                        Type type = new TypeToken<NetResponseEntity>() {
                        }.getType();
                        return new Gson().fromJson(string, type);
                    }
                });
    }

    @Override
    public Observable<NetResponseEntity<GetBindInfoResponseEntity>> getBracelet(GetDeviceBindInfoRequestEntity entity, int cacheType) {
        return NetworkRequest.requestFromNet(context, true, NetworkRequest.GET, entity
                , cacheType, new Mapper<NetResponseEntity<GetBindInfoResponseEntity>>() {
                    @Override
                    public NetResponseEntity<GetBindInfoResponseEntity> mapToEntity(String string) {
                        Type type = new TypeToken<NetResponseEntity<List<GetBindInfoResponseEntity>>>() {
                        }.getType();
                        return new Gson().fromJson(string, type);
                    }
                });
    }

    @Override
    public Observable<NetResponseEntity<BraceletConfigEntity>> getConfig(GetBraceletConfigRequestEntity entity, int cacheType) {
        return NetworkRequest.requestFromNet(context, true, NetworkRequest.GET, entity
                , cacheType, new Mapper<NetResponseEntity<BraceletConfigEntity>>() {
                    @Override
                    public NetResponseEntity<BraceletConfigEntity> mapToEntity(String string) {
                        Type type = new TypeToken<NetResponseEntity<BraceletConfigEntity>>() {
                        }.getType();
                        return new Gson().fromJson(string, type);
                    }
                });
    }

    @Override
    public Observable<NetResponseEntity> setConfig(BraceletConfigEntity entity) {
        return NetworkRequest.requestFromNet(context, true, NetworkRequest.POST, entity
                , NetConstant.NO_CACHE, new Mapper<NetResponseEntity>() {
                    @Override
                    public NetResponseEntity mapToEntity(String string) {
                        Type type = new TypeToken<NetResponseEntity>() {
                        }.getType();
                        return new Gson().fromJson(string, type);
                    }
                });
    }

    @Override
    public Observable<NetResponseEntity> setInfo(SetBraceletInfoRequestEntity entity) {
        return null;
    }
}
