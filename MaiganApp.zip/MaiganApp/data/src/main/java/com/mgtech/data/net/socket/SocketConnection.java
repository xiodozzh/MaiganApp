package com.mgtech.data.net.socket;

import android.util.Log;

import com.mgtech.domain.entity.SocketListener;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

/**
 * web socket connection
 */

public class SocketConnection {
    private static final String TAG = "socket";
    private String url;
    private WebSocket webSocket;
    private SocketListener socketListener;

    public SocketConnection(String url, SocketListener listener) {
        this.url = url;
        this.socketListener = listener;
    }
    private OkHttpClient createClient() {
        return new OkHttpClient().newBuilder().build();
    }

    public void connect(){
        if (webSocket != null){
            return;
        }
        Request request = new Request.Builder().url(url).build();
        OkHttpClient client = createClient();
        webSocket = client.newWebSocket(request, webSocketListener);
        // 关闭
        client.dispatcher().executorService().shutdown();
    }

    private WebSocketListener webSocketListener = new WebSocketListener() {
        @Override
        public void onOpen(WebSocket webSocket, Response response) {
            super.onOpen(webSocket, response);
            if (socketListener != null){
                socketListener.onOpen();
            }
        }

        @Override
        public void onMessage(WebSocket webSocket, String text) {
            super.onMessage(webSocket, text);
            if (socketListener != null){
                socketListener.onMessage(text);
            }
        }

        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
            super.onMessage(webSocket, bytes);
        }

        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            Log.i("socket", "onClosing: reason "+ reason + "  code "+code);
            close();
            super.onClosing(webSocket, code, reason);
        }

        @Override
        public void onClosed(WebSocket webSocket, int code, String reason) {
            Log.i("socket", "onClosing: "+ reason + " "+code);
            if (socketListener != null){
                socketListener.onClose();
            }
            super.onClosed(webSocket, code, reason);
            Log.i("socket", "onClosed: "+ reason + " "+code);
        }

        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
            super.onFailure(webSocket, t, response);
            if (socketListener != null){
                socketListener.onFail();
            }
            t.printStackTrace();
        }
    };

    public void send(String text){
        if (webSocket != null){
            Log.i(TAG, "send: " + text);
            webSocket.send(text);
        }
    }

    public void close(){
        Log.e("socket", "close: tttttt" );
        if (webSocket != null){
            webSocket.close(1000,"断开");
            webSocket = null;
        }
    }
}
